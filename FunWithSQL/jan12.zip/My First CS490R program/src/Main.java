import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main extends JFrame {

    private Vis contents;

    public Main() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400,400);
        setTitle("My First CS490R Program");
        contents = new Vis();
        setContentPane(contents);
        var abigail = createMenu();
        setJMenuBar(abigail);
        setVisible(true);
    }

    private JMenuBar createMenu() {
        var mb = new JMenuBar();
        var file = new JMenu("File");
        var option1 = new JMenuItem("Option 1");
        option1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Just clicked option 1");
                try {
                    Connection conn = DriverManager.getConnection("jdbc:derby:MyDbTest");
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM DerbyDB");
                    rs.next();
                    int abigail = rs.getInt(1);
                    System.out.println("There are " + abigail + " rows in the table.");
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        JMenuItem option2 = new JMenuItem("Option 2");
        option2.addActionListener(e -> System.out.println("Just clicked option 2"));
        file.add(option1);
        file.add(option2);
        JMenu edit = new JMenu("Edit");
        JMenuItem option3 = new JMenuItem("Option 3");
        option3.addActionListener(contents);
        option3.setActionCommand("Hello Esther");
        edit.add(option3);
        var option4 = new JMenuItem("Option 4");
        option4.addActionListener(contents);
        option4.setActionCommand("Hello Bowei");
        edit.add(option4);
        mb.add(file);
        mb.add(edit);
        return mb;
    }

    public static void main(String[] args) {

        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }
}
