import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Vis extends JPanel implements ActionListener {

    private String greeting;

    public Vis() {
        greeting = "Hello Grace!";
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        greeting = e.getActionCommand();
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawString(greeting, 10, 30);
    }
}
