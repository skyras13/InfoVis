package com.company;

public class Cloud {

    private int x;

    public Cloud() {
        ;
    } // default constructor

    public int getX() { // accessor/GET method for x coordinate
        return x;
    }

    public void setX(int x2) { // mutator/SET method for x coordinate
        x = x2;
    }
}
