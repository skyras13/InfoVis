import com.sun.source.tree.Tree;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Leaf {

    Color color;
    String word;
    int iterations;
    int weight;
    ArrayList<Integer> iterationIndex;
    Rectangle box;

    public Leaf(String name) {
        color = Color.BLACK;
        word = name;
        iterations = 1;
        iterationIndex = new ArrayList<Integer>();
        box = new Rectangle();
        int weight = 0;

//        if(iterationIndex != null){
//            iterationIndex.clear();
//        }
    }

    //used to set the Max Variable

    public String getWord(){
        return word;
    }

    public void addIteration(){
        iterations++;
    }

    public int getIteration(){
        return iterations;
    }

    public void addIterationIndex(int ind){
        iterationIndex.add(ind);
    }

    public void setBox(int x, int y){
//        System.out.println("hit");
        box.setBounds(x,y-10,40,10);
//        box.getBounds();
    }

    public boolean touchWord(int x, int y){

        if(box != null){
            if(box.contains(x,y)){
//                System.out.println(box+" X and Y: "+x+"  "+y+" Label: "+word);
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public Rectangle getBox(){
        return box;
    }

    public void setColor(Color c){
        color = c;
    }

    public void addWeight(){
        weight++;
    }
}
