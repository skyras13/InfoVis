import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Vis extends JPanel implements ActionListener, MouseInputListener {

    private WordTree tree;
    private Leaf leaf;
    private ArrayList<String> fullText;
    private ArrayList<Leaf> treeLeafs;
    private ArrayList<Leaf> over100;
    private ArrayList<Leaf> over50;
    private ArrayList<Leaf> over10;
    private ArrayList<Leaf> displayedWords;
    private ArrayList<Leaf> clickableWords;
    private ArrayList<WordTree> trees;
    private int numTrees;
    private int plus100;
    private int plus50;
    private int plus10;

    public Vis(){
        addMouseListener(this);
        addMouseMotionListener(this);
        fullText = new ArrayList<String>();
        treeLeafs = new ArrayList<Leaf>();
        over100 = new ArrayList<Leaf>();
        over50 = new ArrayList<Leaf>();
        over10 = new ArrayList<Leaf>();
        displayedWords = new ArrayList<Leaf>();
        clickableWords = new ArrayList<Leaf>();
        trees = new ArrayList<WordTree>();
        numTrees = 0;
        plus100 = 0;
        plus50 = 0;
        plus10 = 0;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(treeLeafs != null) {
//            System.out.println("hit");
            treeLeafs.clear();
            fullText.clear();
            over100.clear();
            over50.clear();
            displayedWords.clear();
            trees.clear();

        }

        File file = new File("trumpSpeech.txt");


        fullText = new ArrayList<String>();
        treeLeafs = new ArrayList<Leaf>();
        over100 = new ArrayList<Leaf>();
        over50 = new ArrayList<Leaf>();
        over10 = new ArrayList<Leaf>();
        displayedWords = new ArrayList<Leaf>();
        trees = new ArrayList<WordTree>();
        numTrees = 0;
        plus100 = 0;
        plus50 = 0;
        plus10 = 0;

        try {
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String i = sc.next();
//                i.toUpperCase(Locale.ROOT);
                i = i.replaceAll("\"", "");
                i = i.replaceAll("\\p{Punct}","");
                i = i.replaceAll("^\"|\"$", "");
                fullText.add(i);
            }
            sc.close();
        }
        catch (FileNotFoundException ei) {
            ei.printStackTrace();
        }

        int index = 0;
        for(String text:fullText){
            boolean repeat = false;
            leaf = new Leaf(text);
            if(treeLeafs.isEmpty()){
//                leaf.addIterationIndex(index);
                treeLeafs.add(leaf);
            }
            for(Leaf le:treeLeafs) {
                if (le.getWord().equals(text)) {
                    le.addIteration();
//                    le.addIterationIndex(index);
                    repeat = true;
                }
            }
            if(repeat == false){
//                leaf.addIterationIndex(index);
                treeLeafs.add(leaf);
            }
            index++;
        }

        for(Leaf lea:treeLeafs){
//            System.out.println(lea.getWord()+" entries: "+lea.getIteration());
            if(lea.getIteration()>=100) {
                plus100++;
                over100.add(lea);
            }else if(50<=lea.getIteration() && lea.getIteration()<100){
                plus50++;
                over50.add(lea);
            }else if(25<=lea.getIteration() && lea.getIteration()<50){
                plus10++;
                over10.add(lea);
            }
        }
//        System.out.println("TreeLeaf Size: "+treeLeafs.size()+" FullText Size: "+fullText.size());
        repaint();
    }

    @Override
    public void paintComponent(Graphics g1) {
        Graphics2D g = (Graphics2D) g1;
        int w = getWidth();
        int h = getHeight();

        if(displayedWords != null) {
            displayedWords.clear();
        }

        g.setColor(Color.WHITE);
        g.fillRect(0,0,w,h);

        //initial screen showing most used words in the entire document.
        if(numTrees == 0){

            if(over100 != null) {
                //printing page labels.
                g.setColor(Color.RED);
                g.setFont(new Font("TimesRoman", Font.BOLD, 24));
                g.drawString("Words Used Over 100 Times",(int)(w*.25),(int)(h*.20));

                //printing initial values
                int xbuffer = 20;
                int[] labelCoordinates = new int[plus100];
                g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                for (int i = 0; i < over100.size(); i++) {
                    g.setColor(over100.get(i).color);
                    labelCoordinates[i] = (xbuffer + ((((w-20) - (xbuffer * 2)) / ((labelCoordinates.length) - 1)) * i));
                    g.drawString("" + over100.get(i).getWord(),labelCoordinates[i],Math.round(h*0.33));
                    over100.get(i).setBox(labelCoordinates[i],(int)(Math.round(h*0.33)));
                    displayedWords.add(over100.get(i));
                }
            }

            if(over50 != null) {

                g.setColor(Color.RED);
                g.setFont(new Font("TimesRoman", Font.BOLD, 24));
                g.drawString("Words Used Over 50 Times",(int)(w*.25),(int)(h*.55));

                int xbuffer = 20;
                int[] labelCoordinates50 = new int[plus50];
                g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                for (int i = 0; i < over50.size(); i++) {
                    g.setColor(over50.get(i).color);
                    labelCoordinates50[i] = (xbuffer + ((((w-20) - (xbuffer * 2)) / ((labelCoordinates50.length) - 1)) * i));
                    g.drawString("" + over50.get(i).getWord(),labelCoordinates50[i],Math.round(h*0.66));
                    over50.get(i).setBox(labelCoordinates50[i],(int)(Math.round(h*0.66)));
                    displayedWords.add(over50.get(i));
                }
            }
        }else if(0 < numTrees && numTrees <= 6) {

            int n = 0;
            for (WordTree branch : trees) {
                g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                g.setColor(branch.parent.color);
                g.drawString("" + branch.parent.getWord(), (int) (w/(numTrees+1)*n), (int) (h * 0.50));
                branch.parent.setBox((int) (w/(numTrees+1)*n), (int) (h * 0.50));
//                displayedWords.add(branch.parent);
                n++;
            }
            ArrayList<Leaf> leafPrint = new ArrayList<Leaf>();
            if(tree.childLeafs.size()>50){
                for(Leaf above1:tree.childLeafs){
                    if(above1.getIteration()>1){
                        leafPrint.add(above1);
                    }
                }
            }else{
                for(Leaf all:tree.childLeafs){
                    leafPrint.add(all);
                }
            }

            for(Leaf leafSize:leafPrint){
                if(leafPrint.size()>=40){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 10));
                }else if(25<=leafPrint.size()&&leafPrint.size()<40){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 12));
                }else if(10<=leafPrint.size()&&leafPrint.size()<25){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 14));
                }else{
                    g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                }

                if(leafSize.color.equals(Color.red)){
                    leafSize.setColor(Color.red);
                }else if(leafSize.getIteration()==1){
                    leafSize.setColor(Color.LIGHT_GRAY);
                }else if(leafSize.getIteration()==2){
                    leafSize.setColor(Color.gray);
                }else if(leafSize.getIteration()>2){
                    leafSize.setColor(Color.BLACK);
                }

            }

            int ybuffer = 20;
            int[] labelCoordinates = new int[leafPrint.size()];
            for (int i = 0; i < leafPrint.size(); i++) {
                g.setColor(leafPrint.get(i).color);
                if(labelCoordinates.length == 1){
                    labelCoordinates[i] = (int)(h*.50);
                }else{
                    labelCoordinates[i] = (h - (ybuffer + (((h - (ybuffer * 2)) / ((labelCoordinates.length)-1)) * i)));                int xSpot = (w/(numTrees+1)*n);
                }
                int xSpot = (w/(numTrees+1)*n);
                int xSpotArrow = (w/(numTrees+1)*(n-1));
                g.drawString("" + leafPrint.get(i).getWord(), xSpot, labelCoordinates[i]);
                g.drawLine(xSpotArrow+50,(int)(h*.50),xSpot-10,labelCoordinates[i]);
                leafPrint.get(i).setBox(xSpot,labelCoordinates[i]);
                displayedWords.add(leafPrint.get(i));
            }
        }else{
            int n = 0;
            for (WordTree branch : trees) {
                g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                g.setColor(branch.parent.color);
                g.drawString("" + branch.parent.getWord(), (int) (w/(numTrees+1)*n), (int) (h * 0.50));
                branch.parent.setBox((int) (w/(numTrees+1)*n), (int) (h * 0.50));
//                displayedWords.add(branch.parent);
                n++;
            }
            ArrayList<Leaf> leafPrint = new ArrayList<Leaf>();
            if(tree.childLeafs.size()>50){
                for(Leaf above1:tree.childLeafs){
                    if(above1.getIteration()>1){
                        leafPrint.add(above1);
                    }
                }
            }else{

                g.setColor(Color.RED);
                g.drawString("Max Selections Reached, Please Start Again", (int)(w*.15),(int)(h*.15));

                for(Leaf all:tree.childLeafs){
                    leafPrint.add(all);
                }
            }

            for(Leaf leafSize:leafPrint){
                if(leafPrint.size()>=40){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 10));
                }else if(25<=leafPrint.size()&&leafPrint.size()<40){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 12));
                }else if(10<=leafPrint.size()&&leafPrint.size()<25){
                    g.setFont(new Font("TimesRoman", Font.BOLD, 14));
                }else{
                    g.setFont(new Font("TimesRoman", Font.BOLD, 16));
                }

                if(leafSize.color.equals(Color.red)){
                    leafSize.setColor(Color.red);
                }else if(leafSize.getIteration()==1){
                    leafSize.setColor(Color.LIGHT_GRAY);
                }else if(leafSize.getIteration()==2){
                    leafSize.setColor(Color.gray);
                }else if(leafSize.getIteration()>2){
                    leafSize.setColor(Color.BLACK);
                }

            }

            int ybuffer = 20;
            int[] labelCoordinates = new int[leafPrint.size()];
            for (int i = 0; i < leafPrint.size(); i++) {
                g.setColor(leafPrint.get(i).color);
                if(labelCoordinates.length == 1){
                    labelCoordinates[i] = (int)(h*.50);
                }else{
                    labelCoordinates[i] = (h - (ybuffer + (((h - (ybuffer * 2)) / ((labelCoordinates.length)-1)) * i)));                int xSpot = (w/(numTrees+1)*n);
                }
                int xSpot = (w/(numTrees+1)*n);
                int xSpotArrow = (w+100/(numTrees+1)*(n-1));
                g.drawString("" + leafPrint.get(i).getWord(), xSpot, labelCoordinates[i]);
                g.drawLine(xSpotArrow,(int)(h*.50),xSpot-5,labelCoordinates[i]);
                leafPrint.get(i).setBox(xSpot,labelCoordinates[i]);
//                displayedWords.add(leafPrint.get(i));
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();

        for(Leaf over:displayedWords){
//            System.out.println("display: "+displayedWords.size());
            if(over.touchWord(x,y) == true){
                if(numTrees == 0) {
                    tree = new WordTree(over, fullText, treeLeafs);
                    tree.printChildLeaf();
                    System.out.println(tree.parent.getWord());
                    trees.add(tree);
                    over.setColor(Color.BLACK);
                    numTrees++;
                }else if(0 < numTrees && numTrees <= 5){
                    boolean inTree = false;
                    treeLeafs.clear();
                    for (int newIndex : over.iterationIndex) {
                        System.out.println("New iteration Index: "+over.iterationIndex);
                        for (int i = 0; i < fullText.size(); i++) {
                            if (newIndex == i) {
                                int place = 0;
                                for(int j = (trees.size()-1); j>=0; j--){
                                    if(trees.get(place).parent.getWord().equals(fullText.get(i-j))){
                                        inTree = true;
                                        place++;
                                    }else{
                                        inTree = false;
                                    }
                                }
                                if(inTree == true) {
                                    leaf = new Leaf(fullText.get(i + 2));
                                    treeLeafs.add(leaf);
                                }
                            }
                        }
                    }
                    System.out.println("treeLeafs: "+treeLeafs.size());
                    tree = new WordTree(over, fullText, treeLeafs);
                    tree.printChildLeaf();
                    System.out.println(tree.parent.getWord());
                    trees.add(tree);
                    over.setColor(Color.BLACK);
                    numTrees++;
                }else{
                    numTrees++;
                }
                break;
            }
        }
        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
//        System.out.println("displayWords Size: "+displayedWords.size());
        for(Leaf over:displayedWords){
            if(over.touchWord(x,y) == true){
//                System.out.println(over.getWord());
                setToolTipText("Weight: "+over.getIteration());
                over.setColor(Color.red);
                break;
            }else{
                setToolTipText(null);
                over.setColor(Color.BLACK);
            }
        }
        repaint();
    }
}

