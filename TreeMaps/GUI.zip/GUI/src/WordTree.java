import java.util.ArrayList;

public class WordTree {

    Leaf parent;
    Leaf child;
    ArrayList<String> wordSet;
    ArrayList<Leaf> leafSet;
    ArrayList<Leaf> childLeafs;

    public WordTree(Leaf name, ArrayList<String> set, ArrayList<Leaf> leafs) {
        parent = name;
        wordSet = set;
        leafSet = leafs;
        childLeafs = new ArrayList<>();

        for(Leaf leaf:leafs){
            leaf.iterations = 0;
        }

        addChildLeaf(parent.getWord(),wordSet,leafSet);
    }


    public void addChildLeaf(String l,ArrayList<String> tester, ArrayList<Leaf> leafs){
        System.out.println("Parent Node: "+l);
        for(int i = 0; i < tester.size();i++){
            if(tester.get(i).equals(l)){
                for(Leaf lf:leafs){
//                    System.out.println(lf.getWord());
                    if(i<(tester.size())-1) {
                        if (lf.getWord().equals(tester.get(i+1))) {
                            boolean repeat = false;
                            child = lf;
//                            child.iterations = 1;

                            if(childLeafs.isEmpty()){
//                                child.addIteration();
//                                child.addIterationIndex(i);
                                childLeafs.add(child);
                                child.addWeight();
                            }

                            for(Leaf le:childLeafs) {
                                if (le.getWord().equals(tester.get(i+1))) {
                                    le.addIteration();
                                    le.addIterationIndex(i);
                                    repeat = true;
                                }
                            }
                            if(repeat == false){
                                child.addIteration();
                                child.addIterationIndex(i);
                                childLeafs.add(child);
                                child.addWeight();
                            }
                        }
                    }
                }
            }
        }
    }

    public void printChildLeaf(){
        System.out.println("Num ChildLeaf: "+childLeafs.size());
        for(Leaf child:childLeafs){
            System.out.println("Child Node " + child.getWord()+" Interation: "+child.getIteration()+" Index: "+child.iterationIndex);
        }
    }

    public ArrayList<Leaf> getLeafSet(){
        return leafSet;
    }
}
